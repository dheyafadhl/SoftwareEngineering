from django.shortcuts import render, redirect, get_object_or_404
from .data import context
from .models import Students
from .forms import StudentForm
# Create your views here.

def student(request):
    return render(request, 'webPage.html', {'students':context})

# def index(request):
#     return render(request, 'read_time_filter.html', {'students':context})

def test_page(request):
    post1_content = """
    هذا نص تجريبي قصير جدًا. الهدف منه هو اختبار حالة ما إذا كان وقت القراءة التقديري أقل من دقيقة واحدة. الفلتر يجب أن يعرض رسالة مناسبة لهذه الحالة. لنرى كيف سيعمل.
    """

    post2_content = """
    هذا المقال أطول قليلاً من سابقه. تم تصميمه ليكون طوله حوالي 200 كلمة، وهو المتوسط الذي يستخدمه الفلتر كقيمة افتراضية. بناءً على هذا العدد من الكلمات، من المتوقع أن يكون وقت القراءة دقيقة واحدة بالضبط. هذا يسمح لنا باختبار الشرط الثاني في الفلتر، وهو عندما تكون النتيجة تساوي دقيقة واحدة. يجب أن نرى كيف يتعامل الفلتر مع هذه الحالة بدقة. النص هنا يتوسع ليشمل تفاصيل إضافية حول أهمية الفلاتر في Django وكيف أنها تساعد في فصل منطق العرض عن منطق العمليات. فلاتر القوالب هي أدوات قوية تسمح للمطورين بتعديل كيفية عرض المتغيرات في القالب دون الحاجة لكتابة كود معقد في العروض (views). هذا المبدأ، المعروف بفصل الاهتمامات (Separation of Concerns)، هو من أفضل الممارسات في تطوير البرمجيات ويجعل الكود أكثر قابلية للصيانة والتوسع في المستقبل. استخدام الفلاتر المخصصة مثل فلتر "وقت القراءة" هو مثال رائع على كيفية تطبيق هذا المبدأ بشكل عملي وفعال في مشاريع Django. يتيح لنا هذا الفلتر إضافة ميزة مفيدة للمستخدمين دون تعقيد الكود الأساسي للتطبيق.
    """

    post3_content = """
    الآن، ننتقل إلى مقال أطول بكثير لاختبار الحالة الثالثة والأخيرة للفلتر. هذا النص يتجاوز الـ 400 كلمة، مما يعني أن وقت القراءة التقديري يجب أن يكون عدة دقائق. من خلال هذا الاختبار، نتأكد من أن الفلتر قادر على التعامل مع النصوص الطويلة وإرجاع عدد الدقائق الصحيح والمقرب لأعلى. على سبيل المثال، إذا كان عدد الكلمات 450، وباستخدام المعدل الافتراضي (200 كلمة في الدقيقة)، ستكون النتيجة 2.25، والتي يجب أن يقربها الفلتر إلى 3 دقائق. هذا التقريب لأعلى مهم لضمان عدم إعطاء تقدير أقل من الواقع، مما يحسن تجربة المستخدم. المقالات الطويلة شائعة في المدونات والمواقع الإخبارية، ووجود مؤشر لوقت القراءة يساعد القارئ على تحديد ما إذا كان لديه الوقت الكافي لقراءة المقال كاملاً أم يفضل حفظه لوقت لاحق. تعتبر هذه الميزة الصغيرة إضافة قيمة للمواقع التي تركز على المحتوى المكتوب. دعونا نضيف المزيد من الكلمات فقط لنتأكد من أننا نتجاوز الحد المطلوب بوضوح. الابتكار في تطوير الويب لا يتوقف عند الميزات الكبيرة والمعقدة، بل يشمل أيضًا هذه التحسينات الصغيرة التي تجعل تجربة المستخدم أكثر سلاسة ومتعة. إن الاهتمام بالتفاصيل هو ما يميز التطبيق الرائع عن التطبيق الجيد. ومن خلال هذا الفلتر البسيط، نضيف لمسة احترافية تعكس هذا الاهتمام. فلنكمل إضافة المزيد من المحتوى لضمان أن الاختبار شامل ويغطي جميع الجوانب المتوقعة من الفلتر الذي قمنا بتطويره.
    """

    context = {
        'post1_content': post1_content,
        'post2_content': post2_content,
        'post3_content': post3_content,
    }
    return render(request, 'test_reading_time.html', context)

def home(request):
    return render(request, 'home.html')

def list_students(request):
    students = {
        'name':'dheya',
        'marks':[91, 80, 86],
        'each':{
            'theory':65,
            'programming':80
        },
        'total':300
    }
    return render(request, 'showstudents.html', students)

def edit_students(request):
    return render(request, 'editstudents.html')

def deletestudents(request):
    return render(request, 'deletestudents.html')


def read(request):
    student = Students.objects.all()
    student_count = Students.objects.all().count()
    return render(request, "showstudents.html", {"students":student, "student_count":student_count})

def read_one(request, id):
    student = Students.objects.get(id=id)
    return render(request, "student_one.html", {"student":student})

def create(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('student:show') # اسم الرابط الذي يعرض قائمة الطلاب
    else:
        form = StudentForm()
    return render(request, 'addstudent.html', {'form': form})

def update(request, id):
    student = get_object_or_404(Students, id=id)
    if request.method == 'POST':
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            return redirect('student:show')
    else:
        form = StudentForm(instance=student)
    return render(request, 'updatestudent.html', {'form': form, 'student': student})

def delete(request, id):
    student = Students.objects.get(id=id).delete()
    return redirect("student:show")