context = [
    {
        "FirstName": "فاطمة",
        "LastName": "الهاجري",
        "Age": 45,
        "Gender": "أنثى",
        "Specialization": "الرياضيات",
        "IsHeadOfDepartment": "نعم"
    },
    {
        "FirstName": "علي",
        "LastName": "المنصوري",
        "Age": 52,
        "Gender": "ذكر",
        "Specialization": "الفيزياء",
        "IsHeadOfDepartment": "لا"
    },
    {
        "FirstName": "عائشة",
        "LastName": "الكعبي",
        "Age": 38,
        "Gender": "أنثى",
        "Specialization": "اللغة العربية",
        "IsHeadOfDepartment": "لا"
    },
    {
        "FirstName": "سلطان",
        "LastName": "الجابري",
        "Age": 48,
        "Gender": "ذكر",
        "Specialization": "التاريخ",
        "IsHeadOfDepartment": "نعم"
    },
    {
        "FirstName": "نورة",
        "LastName": "الشامسي",
        "Age": 41,
        "Gender": "أنثى",
        "Specialization": "الكيمياء",
        "IsHeadOfDepartment": "لا"
    },
    {
        "FirstName": "حسن",
        "LastName": "المهيري",
        "Age": 55,
        "Gender": "ذكر",
        "Specialization": "علوم الحاسوب",
        "IsHeadOfDepartment": "نعم"
    },
    {
        "FirstName": "شيخة",
        "LastName": "الفلاسي",
        "Age": 39,
        "Gender": "أنثى",
        "Specialization": "الأحياء",
        "IsHeadOfDepartment": "لا"
    },
    {
        "FirstName": "راشد",
        "LastName": "الكتبي",
        "Age": 46,
        "Gender": "ذكر",
        "Specialization": "الجغرافيا",
        "IsHeadOfDepartment": "لا"
    },
    {
        "FirstName": "موزة",
        "LastName": "الغفلي",
        "Age": 43,
        "Gender": "أنثى",
        "Specialization": "اللغة الإنجليزية",
        "IsHeadOfDepartment": "نعم"
    },
    {
        "FirstName": "سيف",
        "LastName": "السويدي",
        "Age": 50,
        "Gender": "ذكر",
        "Specialization": "التربية الفنية",
        "IsHeadOfDepartment": "لا"
    }
]